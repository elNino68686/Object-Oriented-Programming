package com.company;

public class Goalkeeper extends Player{

    private int elasticity;
    private int hability;

    public Goalkeeper(String name, int spd, int end, int dex, int str, int hg, int kick, int pass, int elast) {
        super(name, spd, end, dex, str, hg, kick, pass);
        this.elasticity = elast;

        hability = (int) (100 * (0.25 * this.elasticity + 0.05 * this.getSpeed()) + 0.05 * this.getEndurance() + 0.2 * this.getDexterity() + 0.05 * this.getStrength() + 0.2 * this.getHeadGame() + 0.05 * this.getKick() + 0.05 * this.getPass());
    }

    public int getHability() {
        return hability;
    }
}
