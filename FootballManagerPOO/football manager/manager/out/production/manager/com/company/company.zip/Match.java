package com.company;

import java.util.Date;

public class Match {

    private FootballTeam teamA;
    private FootballTeam teamB;
    private int teamAScore;
    private int teamBScore;
    private Date date;

    public FootballTeam getTeamA() {
        return teamA;
    }

    public FootballTeam getTeamB() {
        return teamB;
    }

    public int getTeamAScore(){
        return teamAScore;
    }

    public int getTeamBScore(){
        return teamBScore;
    }

    public Date getDate() {
        return date;
    }

    public void setTeamA(FootballTeam teamA) {
        this.teamA = teamA;
    }

    public void setTeamB(FootballTeam teamB) {
        this.teamB = teamB;
    }

    public void setTeamAScore(int teamAScore) {
        this.teamAScore = teamAScore;
    }

    public void setTeamBScore(int teamBScore) {
        this.teamBScore = teamBScore;
    }

    public void setDate(Date date) {
        this.date = date;
    }
}
