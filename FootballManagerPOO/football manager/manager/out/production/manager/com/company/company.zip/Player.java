package com.company;

public abstract class Player {

    private String name;
    private int speed;
    private int endurance;
    private int dexterity;
    private int impulse;
    private int headGame;
    private int kick;
    private int pass;

    public Player(String name, int spd, int end, int dex, int imp, int hg, int kick, int pass) {
        this.name = name;
        this.speed = spd;
        this.endurance = end;
        this.dexterity = dex;
        this.impulse = imp;
        this.headGame = hg;
        this.kick = kick;
        this.pass = pass;
    }

    public Player(Player player) {
        this.name = player.getName();
        this.endurance = player.getEndurance();
        this.dexterity = player.getDexterity();
        this.impulse = player.getStrength();
        this.headGame = player.getHeadGame();
        this.kick = player.getKick();
        this.pass = player.getPass();
    }

    @Override
    public boolean equals(Object o) {
        return this.name.equals(((Player)o).name);
    }

    public String getName() {
        return name;
    }

    public int getSpeed() {
        return speed;
    }

    public int getEndurance() {
        return endurance;
    }

    public int getDexterity() {
        return dexterity;
    }

    public int getStrength() {
        return impulse;
    }

    public int getHeadGame() {
        return headGame;
    }

    public int getKick() {
        return kick;
    }

    public int getPass() {
        return pass;
    }

    @Override
    public String toString() {
        return "Player{" +
                "name='" + name + '\'' +
                ", speed=" + speed +
                ", endurance=" + endurance +
                ", dexterity=" + dexterity +
                ", strength=" + impulse +
                ", headGame=" + headGame +
                ", kick=" + kick +
                ", pass=" + pass +
                "}\n";
    }

    public abstract int getHability();
}
