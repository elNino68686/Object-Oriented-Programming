package com.company;

import java.util.ArrayList;
import java.util.List;

public abstract class Team {

    private String name;
    private String location;
    private String statistics;
    private List<Player> players;
    private List<Player> substitutePlayers;

    public Team(String name, String loc){
        this.name = name;
        this.location = loc;
        this.players = new ArrayList<>();
        this.substitutePlayers = new ArrayList<>();
    }

    //public Team(Team team) {
    //    this.name = team.getName();
    //    this.location = team.getLocation();
    //    this.players = team.getPlayers().stream().map(player -> new Player(player))
    //    this.substitutePlayers = team.getSubstitutePlayers();
    //}

    @Override
    public boolean equals(Object o) {
        return this.name.equals(((Team)o).name);
    }

    public String getName() {
        return name;
    }

    public String getLocation() {
        return location;
    }

    public String getStatistics() {
        return statistics;
    }

    public void setLocation(String s) {
        this.location = s;
    }

    public void setName(String s) {
        this.name = s;
    }

    public void setStatistics(String s) {
        this.statistics = s;
    }

    public void add(Player p) {
        substitutePlayers.add(p);
    }

    public List<Player> getPlayers() {
        return players;
    }

    public List<Player> getSubstitutePlayers() {
        return substitutePlayers;
    }

    @Override
    public String toString() {
        return "Team{" +
                "name='" + name + '\'' +
                ", location='" + location + '\'' +
                ", statistics='" + statistics + '\'' +
                ", players=" + players +
                ", substitutePlayers=" + substitutePlayers +
                '}';
    }

    public abstract int totalHability();

    //public abstract Team clone();

}
