package com.company;

public class Forward extends Player{

    int hability;

    public Forward(String name, int spd, int end, int dex, int str, int hg, int kick, int pass) {
        super(name, spd, end, dex, str, hg, kick, pass);
        hability = (int) (100 * (0.05 * this.getSpeed()) + 0.05 * this.getEndurance() + 0.2 * this.getDexterity() + 0.05 * this.getStrength() + 0.2 * this.getHeadGame() + 0.05 * this.getKick());
    }

    public int getHability() {
        return this.hability;
    }
}
