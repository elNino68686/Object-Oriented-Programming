package com.company;

import java.nio.file.Paths;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.*;

public class UserInterface {

    private final int numberOfClubs;
    private final ArrayList<FootballTeam> teams;
    private final Scanner scanner;
    private final ArrayList<Match> matches;
    private final List<Player> unassignedPlayers;

    public UserInterface(int numberOfClubs) {
        this.numberOfClubs = numberOfClubs;
        this.teams = new ArrayList<>();
        this.matches = new ArrayList<>();
        this.scanner = new Scanner(System.in);
        this.unassignedPlayers = new ArrayList<>();
        populate();
        displayMenu();

    }

    private void populate() {
        Goalkeeper gk0 = new Goalkeeper("gk",1,1,1,1,1,1,1,1);
        Goalkeeper gk1 = new Goalkeeper("gk",1,1,1,1,1,1,1,1);
        Goalkeeper gk2 = new Goalkeeper("gk",1,1,1,1,1,1,1,1);
        Goalkeeper gk3 = new Goalkeeper("gk",1,1,1,1,1,1,1,1);
        Defender def0 = new Defender("gk",1,1,1,1,1,1,1);
        Defender def1 = new Defender("gk",1,1,1,1,1,1,1);
        Defender def2 = new Defender("gk",1,1,1,1,1,1,1);
        Defender def3 = new Defender("gk",1,1,1,1,1,1,1);
        Forward for0 = new Forward("gk",1,1,1,1,1,1,1);
        Forward for1 = new Forward("gk",5,1,1,1,1,1,1);
        Forward for2 = new Forward("gk",1,1,1,1,1,1,1);
        Forward for3 = new Forward("gk",1,1,1,1,1,1,1);
        Lateral lat0 = new Lateral("gk",1,1,1,1,1,1,1,1);
        Lateral lat1 = new Lateral("gk",1,1,1,1,1,1,1,1);
        Lateral lat2 = new Lateral("gk",1,1,1,1,1,1,1,1);
        Lateral lat3 = new Lateral("gk",1,1,1,1,1,1,1,1);
        Midfielder mid0 = new Midfielder("gk",1,1,1,1,1,1,1,1);
        Midfielder mid1 = new Midfielder("gk",1,1,1,1,1,1,1,1);
        Midfielder mid2 = new Midfielder("gk",1,1,1,1,1,1,1,1);
        Midfielder mid3 = new Midfielder("gk",1,1,1,1,1,1,1,1);
        FootballTeam t1 = new FootballTeam("t1", "loc1");
        FootballTeam t2 = new FootballTeam("t1", "loc1");
        FootballTeam t3 = new FootballTeam("t1", "loc1");
        FootballTeam t4 = new FootballTeam("t1", "loc1");
        unassignedPlayers.add(gk0);
        unassignedPlayers.add(def0);
        unassignedPlayers.add(for0);
        unassignedPlayers.add(lat0);
        unassignedPlayers.add(mid0);
        t1.add(gk1);
        t1.add(def1);
        t1.add(for1);
        t1.add(lat1);
        t1.add(mid1);
        teams.add(t1);
        t2.add(gk2);
        t2.add(def2);
        t2.add(for2);
        t2.add(lat2);
        t2.add(mid2);
        teams.add(t2);
        t3.add(gk3);
        t3.add(def3);
        t3.add(for3);
        t3.add(lat3);
        t3.add(mid3);
        teams.add(t3);
        teams.add(t4);

        try (Scanner scanner = new Scanner(Paths.get("C:\\Users\\marlo\\IdeaProjects\\manager\\src\\com\\company\\logsV2.txt"))) {
            while (scanner.hasNextLine()) {
                String line = scanner.nextLine();
                String[] linhaPartida = line.split(":");
                switch (linhaPartida[0]) {
                    case "Equipa":
                        FootballTeam team = new FootballTeam(linhaPartida[1], "na");
                        do {
                            line = scanner.nextLine();
                            linhaPartida = line.split(":");
                            switch (linhaPartida[0]) {
                                case "Guarda-Redes":
                                    String[] campos = linhaPartida[1].split(",");
                                    String nomeJog = campos[0];
                                    System.out.println("gk: " + nomeJog);
                                    int spd = Integer.parseInt(campos[1]);
                                    int end = Integer.parseInt(campos[2]);
                                    int dex = Integer.parseInt(campos[3]);
                                    int imp = Integer.parseInt(campos[4]);
                                    int hg = Integer.parseInt(campos[5]);
                                    int kick = Integer.parseInt(campos[6]);
                                    int pass = Integer.parseInt(campos[7]);
                                    int elast = Integer.parseInt(campos[8]);
                                    team.add(new Goalkeeper(nomeJog, spd, end, dex, imp, hg, kick, pass, elast));
                                    break;
                                case "Lateral":
                                    campos = linhaPartida[1].split(",");
                                    nomeJog = campos[0];
                                    System.out.println("lat: " + nomeJog);
                                    spd = Integer.parseInt(campos[1]);
                                    end = Integer.parseInt(campos[2]);
                                    dex = Integer.parseInt(campos[3]);
                                    imp = Integer.parseInt(campos[4]);
                                    hg = Integer.parseInt(campos[5]);
                                    kick = Integer.parseInt(campos[6]);
                                    pass = Integer.parseInt(campos[7]);
                                    int cross = Integer.parseInt(campos[8]);
                                    team.add(new Lateral(nomeJog, spd, end, dex, imp, hg, kick, pass, cross));
                                    break;
                                case "Defesa":
                                    campos = linhaPartida[1].split(",");
                                    nomeJog = campos[0];
                                    spd = Integer.parseInt(campos[1]);
                                    end = Integer.parseInt(campos[2]);
                                    dex = Integer.parseInt(campos[3]);
                                    imp = Integer.parseInt(campos[4]);
                                    hg = Integer.parseInt(campos[5]);
                                    kick = Integer.parseInt(campos[6]);
                                    pass = Integer.parseInt(campos[7]);
                                    team.add(new Defender(nomeJog, spd, end, dex, imp, hg, kick, pass));
                                    break;
                                case "Medio":
                                    campos = linhaPartida[1].split(",");
                                    nomeJog = campos[0];
                                    spd = Integer.parseInt(campos[1]);
                                    end = Integer.parseInt(campos[2]);
                                    dex = Integer.parseInt(campos[3]);
                                    imp = Integer.parseInt(campos[4]);
                                    hg = Integer.parseInt(campos[5]);
                                    kick = Integer.parseInt(campos[6]);
                                    pass = Integer.parseInt(campos[7]);
                                    int rec = Integer.parseInt(campos[8]);
                                    team.add(new Midfielder(nomeJog, spd, end, dex, imp, hg, kick, pass, rec));
                                    break;
                                case "Avancado":
                                    campos = linhaPartida[1].split(",");
                                    nomeJog = campos[0];
                                    spd = Integer.parseInt(campos[1]);
                                    end = Integer.parseInt(campos[2]);
                                    dex = Integer.parseInt(campos[3]);
                                    imp = Integer.parseInt(campos[4]);
                                    hg = Integer.parseInt(campos[5]);
                                    kick = Integer.parseInt(campos[6]);
                                    pass = Integer.parseInt(campos[7]);
                                    team.add(new Forward(nomeJog, spd, end, dex, imp, hg, kick, pass));
                                    break;
                            }
                        } while (scanner.hasNextLine() && !linhaPartida[0].equals("Equipa"));
                        teams.add(team);
                }
            }

        } catch (Exception e) {
            System.out.println("Error: " + e.getMessage());
        }

    }

    private void anyKey() {
        System.out.println("Enter any key");
        scanner.nextLine();
    }

    private void displayMenu() {

        while(true) {
            System.out.println("==== Football Manager ====");
            System.out.println("1: New Player");
            System.out.println("2: New team");
            System.out.println("3: Quick game");
            System.out.println("4: Delete existing team from league");
            System.out.println("5: Display Statistics for team");
            System.out.println("6: Display the Premier League Table");
            System.out.println("7: Add a Played Match");
            System.out.println("8: Display Calendar and Find Match");
            System.out.println("0: Exit");
            String line = scanner.nextLine();
            int command = 0;
            try {
                command = Integer.parseInt(line);
            } catch (Exception e) {
            }

            switch(command) {
                case 1 :
                    unassignedPlayers.add(createPlayer());
                    break;
                case 2 :
                    addTeam();
                    break;
                case 3 :
                    quickGame();
                    break;
                case 4 :
                    deleteTeam();
                    break;
                case 5 :
                    displayStatistics();
                    break;
                case 6:
                    displayLeagueTable();
                    break;
                case 7:
                    addPlayedMatch();
                    break;
                case 8:
                    displayCalendar();
                    break;

                case 0:
                    return;
                default:
                    System.out.println("Wrong Command");
            }

        }
    }

    private void quickGame() {
        while (true) {
            int team1Valid = 0;
            System.out.println("==== Quick Game ====");
            System.out.println("Available teams:");
            printTeams();
            System.out.println("Select Team 1");
            int team1 = Integer.parseInt(scanner.nextLine());
            if (team1 >= teams.size()) {
                System.out.println("Select a team from the list");
                anyKey();
            } else team1Valid = 1;
            if (team1Valid == 1) {
                System.out.println("Select Team 2");
                int team2 = Integer.parseInt(scanner.nextLine());
                if (team2 >= teams.size()) {
                    System.out.println("Select a team from the list");
                    anyKey();
                } else {
                    if (teams.get(team1).totalHability() > teams.get(team2).totalHability()) {
                        System.out.println("team1 Wins");
                        anyKey();
                    } else if (teams.get(team1).totalHability() < teams.get(team2).totalHability()) {
                        System.out.println("team2 Wins");
                        anyKey();
                    } else {
                        System.out.println("It's a Draw");
                        anyKey();
                    }
                    return;
                }
            }

        }

    }

    private void printTeams() {
        int i = 0;
        for (Team team: teams) {
            System.out.println(i + ": " + team);
            i++;
        }
    }

    private Player createPlayer() {
        while (true) {
            System.out.println("==== Player Creation ====");
            System.out.println("What is the role?");
            System.out.println("Goalkeeper (press 1)");
            System.out.println("Defender (press 2)");
            System.out.println("Lateral (press 3)");
            System.out.println("Midfielder (press 4)");
            System.out.println("Forward (press 5)");
            String line = scanner.nextLine();
            int command = 0;
            try {
                command = Integer.parseInt(line);
            } catch (Exception e) {
            }
            if (command < 6 && command > 0) {
                System.out.println("Name:");
                String name = scanner.nextLine();
                System.out.println("Speed:");
                int spd = Integer.parseInt(scanner.nextLine());
                System.out.println("Endurance:");
                int end = Integer.parseInt(scanner.nextLine());
                System.out.println("Dexterity:");
                int dex = Integer.parseInt(scanner.nextLine());
                System.out.println("Strength:");
                int str = Integer.parseInt(scanner.nextLine());
                System.out.println("HeadGame:");
                int hg = Integer.parseInt(scanner.nextLine());
                System.out.println("Kick:");
                int kick = Integer.parseInt(scanner.nextLine());
                System.out.println("Pass:");
                int pass = Integer.parseInt(scanner.nextLine());

                switch (command) {
                    case 1:
                        System.out.println("Elasticity:");
                        int elast = Integer.parseInt(scanner.nextLine());
                        Player gk = new Goalkeeper(name, spd, end, dex, str, hg, kick, pass, elast);
                        return gk;
                    case 2:
                        Player def = new Defender(name, spd, end, dex, str, hg, kick, pass);
                        return def;
                    case 3:
                        System.out.println("Cross:");
                        int cross = Integer.parseInt(scanner.nextLine());
                        Player lat = new Lateral(name, spd, end, dex, str, hg, kick, pass, cross);
                        return lat;
                    case 4:
                        System.out.println("Recovery:");
                        int rec = Integer.parseInt(scanner.nextLine());
                        Player mid = new Midfielder(name, spd, end, dex, str, hg, kick, pass, rec);
                        return mid;
                    case 5:
                        Player forw = new Forward(name, spd, end, dex, str, hg, kick, pass);
                        return forw;
                    default:
                        System.out.println("Wrong Command");
                }
            } else System.out.println("Wrong Command");
        }
    }

    private void addTeam() {
        if(teams.size() == numberOfClubs) {
            System.out.println("Can't add more clubs to league");
            return;
        }
        System.out.println("==== Team Creation ====");
        System.out.println("Insert Club Name: ");
        String name = scanner.nextLine();

        //if(league.contains(name)){
        //    System.out.println("This club is already in the league");
        //    anyKey();
        //    return;
        //}

        System.out.println("Insert Club Location: ");
        String loc = scanner.nextLine();
        FootballTeam team = new FootballTeam(name, loc);
        while (true) {

            System.out.println("Add existing player (press 1)");
            System.out.println("Create new player (press 2)");
            System.out.println("Return (press 0)");
            String line = scanner.nextLine();
            int command = 0;
            try {
                command = Integer.parseInt(line);
            } catch (Exception e) {
            }
            switch (command) {
                case 1 :
                    if (unassignedPlayers.size() == 0) {
                        System.out.println("There are no players. Please create a new one.");
                        anyKey();
                        break;
                    }
                    printUnassignedPlayers();
                    int playerIndex = Integer.parseInt(scanner.nextLine());
                    team.add(unassignedPlayers.get(playerIndex));
                    unassignedPlayers.remove(playerIndex);
                    break;
                case 2 :
                    team.add(createPlayer());
                    break;
                case 0:
                    return;
                default:
                    System.out.printf("Wrong Command");
            }
            teams.add(team);
        }



    }

    private void printUnassignedPlayers() {
        int i = 0;
        for (Player player: this.unassignedPlayers) {
            System.out.printf(i + ": " + player);
            i++;
        }
    }

    private void deleteTeam() {
        System.out.println("Insert club name: ");
        String line = scanner.nextLine();

        for(FootballTeam club : teams) {
            if(club.getName().equals(line)){
                teams.remove(club);
                System.out.println("Club "+ club.getName()+" removed");
                anyKey();
                return;
            }
        }
        System.out.println("No such club in league");
        anyKey();
    }

    private void displayStatistics() {
        System.out.println("Insert club name: ");
        String line = scanner.nextLine();
        for (FootballTeam club : teams) {
            if(club.getName().equals(line)){
                System.out.println("Club " + club.getName()+ " matches won: " + club.getWinCount());
                System.out.println("Club " + club.getName()+ " matches lost: " + club.getDefeatCount());
                System.out.println("Club " + club.getName()+ " matches draw: " + club.getDrawCount());
                System.out.println("Club " + club.getName()+ " scored goals: " + club.getScoredGoalsCount());
                System.out.println("Club " + club.getName()+ " recieved goals: " + club.getReceivedGoalsCount());
                System.out.println("Club " + club.getName()+ " points: " + club.getPoints());
                System.out.println("Club " + club.getName()+ " matches played: " + club.getMatchesPlayed());
                anyKey();
                return;
            }
        }
        System.out.println("No such club in league");
        anyKey();
    }

    private void displayLeagueTable() {
        teams.sort(new CustomComparator());
        for(FootballTeam club : teams) {
            System.out.println("Club: " + club.getName()+" Points: "+ club.getPoints()+" goal difference: "+ (club.getScoredGoalsCount()-club.getReceivedGoalsCount()));
        }
        anyKey();
    }

    private void addPlayedMatch() {

        System.out.println("Enter date (format mm-dd-yyyy): ");
        String line = scanner.nextLine();
        Date date;
        try {
            date = new SimpleDateFormat("MM-dd-yyyy").parse(line);
        } catch (ParseException ex) {
            System.out.println("You have to enter date in format mm-dd-yyyy");
            return;
        }

        System.out.println("Enter Home Team: ");
        line = scanner.nextLine();
        FootballTeam home = null;
        for(FootballTeam club : teams){
            if(club.getName().equals(line))
                home = club;
        }
        if (home == null) {
            System.out.println("No such club in league");
            return;
        }
        System.out.println("Enter Away Team: ");
        line = scanner.nextLine();
        FootballTeam away = null;
        for(FootballTeam club : teams){
            if(club.getName().equals(line))
                away = club;
        }
        if (away == null) {
            System.out.println("No such club in league");
            return;
        }

        System.out.println("Enter home team goals: ");
        line = scanner.nextLine();
        int homeGoals = -1;
        try {
            homeGoals = Integer.parseInt(line);
        } catch (Exception e) {
        }
        if (homeGoals == -1) {
            System.out.println("You have to enter number of goals");
            return;
        }

        System.out.println("Enter away team goals: ");
        line = scanner.nextLine();
        int awayGoals = -1;
        try {
            awayGoals = Integer.parseInt(line);
        } catch (Exception e) {
        }
        if (awayGoals == -1) {
            System.out.println("You have to enter number of goals");
            return;
        }


        Match match = new Match();
        match.setDate(date);
        match.setTeamA(home);
        match.setTeamB(away);
        match.setTeamAScore(awayGoals);
        match.setTeamBScore(homeGoals);
        matches.add(match);
        home.setScoredGoalsCount(home.getScoredGoalsCount()+homeGoals);
        away.setScoredGoalsCount(away.getScoredGoalsCount()+awayGoals);
        home.setRecievedGoalsCount(home.getReceivedGoalsCount()+awayGoals);
        away.setRecievedGoalsCount(away.getReceivedGoalsCount()+homeGoals);
        home.setMatchesPlayed(home.getMatchesPlayed()+1);
        away.setMatchesPlayed(away.getMatchesPlayed()+1);

        if (homeGoals > awayGoals) {
            home.setPoints(home.getPoints()+3);
            home.setWinCount(home.getWinCount()+1);
            away.setDefeatCount(away.getDefeatCount()+1);
        }

        else if (homeGoals < awayGoals) {
            away.setPoints(away.getPoints()+3);
            away.setWinCount(away.getWinCount()+1);
            home.setDefeatCount(home.getDefeatCount()+1);
        }
        else {
            home.setPoints(home.getPoints()+1);
            away.setPoints(away.getPoints()+1);
            home.setDrawCount(home.getDrawCount()+1);
            away.setDrawCount(away.getDrawCount()+1);
        }
    }

    private void displayCalendar() {
        System.out.println("Display Calendar and Find Match (press 6)");
    }
}
